<?php include "header.php"; ?>

<div class="main-content home col-9">


<!-- REPETIR POSTAGENS -->
<?php foreach($data['posts'] as $post): ?>

  <?php $dataFormatada = new DateTime($post['data']); ?>

  <article class="blog-post">
      <h2 class="blog-post-title"><?= $post['titulo']; ?></h2>
      <p class="blog-post-meta"><?= $dataFormatada->format('d / m / Y'); ?> por <a href="#"><?= $post['autor']; ?></a></p>

      <p><?= $post['texto']; ?></p>
      
  </article>

<?php endforeach; ?>

<?php if(sizeof($data['posts']) < 1): ?>
  <article class="blog-post">Nenhuma publicação cadastrada.</article>
<?php endif; ?>


</div><!-- /.main-content-->


<?php include "menu_lateral.php"; ?>


<?php include "footer.php"; ?>
<?php 

    /*redireciona o usuário para a controller principal*/
    header("location: ./app/controllers/BlogController.php?action=home");

<?php
	if(isset($msg) and ($msg != "")){
		echo("<div id='mensagem'>" . $msg . "</div>");
	}
?>

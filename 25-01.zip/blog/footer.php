<footer class="container">
    <p class="float-end"><a href="#">De volta ao topo</a></p>
    <p>© 2022–2023 Projeto Integrador, Annalucia A. Raupp · <a href="#">Privacidade</a> · <a href="#">Termos</a></p>
  </footer>
</main>
       
       
       
       </div><!--/.content row -->
    </div><!--/.container -->

</body>
</html>